package com.boa.kyc.KYCApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KycAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycAppApplication.class, args);
	}

}

